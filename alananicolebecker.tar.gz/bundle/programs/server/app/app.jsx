(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// app.jsx                                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var ReactCSSTransitionGroup = React.addons.CSSTransitionGroup;         // 1
                                                                       //
App = React.createClass({                                              // 4
	displayName: 'App',                                                   //
                                                                       //
	getInitialState: function () {                                        // 5
		return {                                                             // 6
			windowHeight: window.innerHeight                                    // 7
		};                                                                   //
	},                                                                    //
	handleResize: function (e) {                                          // 10
		this.setState({ windowHeight: window.innerHeight });                 // 11
	},                                                                    //
	componentWillMount: function () {                                     // 13
		window.addEventListener('resize', this.handleResize);                // 14
	},                                                                    //
	componentWillUnmount: function () {                                   // 16
		window.removeEventListener('resize', this.handleResize);             // 17
	},                                                                    //
	componentDidMount: function () {                                      // 19
		ReactDOM.render(React.createElement(Login, null), document.getElementById("content"));
		var audio = new Audio('/music/from-eden.mp3');                       // 21
		audio.play();                                                        // 22
	},                                                                    //
	render: function () {                                                 // 24
		return React.createElement(                                          // 25
			'div',                                                              //
			{ id: 'background', style: { minHeight: "" + this.state.windowHeight } },
			React.createElement('div', { id: 'content' })                       //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
Login = React.createClass({                                            // 33
	displayName: 'Login',                                                 //
                                                                       //
	handleSubmit: function (e) {                                          // 34
		e.preventDefault();                                                  // 35
		var answer = ReactDOM.findDOMNode(this.refs.loginAnswer).value.trim().toLowerCase();
		if (answer.indexOf("stella") == -1) {                                // 37
			alert("Are you kidding me? Really?...");                            // 38
			ReactDOM.findDOMNode(this.refs.loginAnswer).value = "";             // 39
		} else {                                                             //
			ReactDOM.unmountComponentAtNode(document.getElementById("content"));
			ReactDOM.render(React.createElement(StoryPart1, null), document.getElementById("content"));
		}                                                                    //
	},                                                                    //
	render: function () {                                                 // 45
		return React.createElement(                                          // 46
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 48
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h1',                                                           //
							{ className: 'text-center' },                                   //
							'Hello Alana'                                                   //
						),                                                               //
						React.createElement(                                             //
							'form',                                                         //
							{ onSubmit: this.handleSubmit },                                //
							React.createElement(                                            //
								'h3',                                                          //
								{ className: 'text-center' },                                  //
								'Where did we go on our first date?'                           //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'spacing' },                                      //
								React.createElement('input', { className: 'block-center', type: 'text', placeholder: 'Answer here', ref: 'loginAnswer' })
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'spacing' },                                      //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple block-center', type: 'submit' },     //
									'Submit'                                                      //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
StoryPart1 = React.createClass({                                       // 69
	displayName: 'StoryPart1',                                            //
                                                                       //
	_handleBack: function () {                                            // 70
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(Login, null), document.getElementById("content"));
	},                                                                    //
	_handleNext: function () {                                            // 74
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart2, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 78
		return React.createElement(                                          // 79
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 81
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							'1 year and 4 days ago, you received these text from me...'     //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement(                                            //
								'a',                                                           //
								{ href: '#text1Modal' },                                       //
								React.createElement('img', { src: '/images/text1.png', alt: 'first text', className: 'block-center max-width-80' })
							)                                                               //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement(                                            //
								'a',                                                           //
								{ href: '#text2Modal' },                                       //
								React.createElement('img', { src: '/images/text2.png', alt: 'second text', className: 'block-center max-width-80' })
							)                                                               //
						),                                                               //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							'...yet, a mere 4 days later, you (for some odd reason) agreed to go on a date with me.'
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleNext },
									'Next'                                                        //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			),                                                                  //
			React.createElement(                                                //
				'div',                                                             //
				{ id: 'text1Modal', className: 'modalDialog' },                    //
				React.createElement(                                               //
					'div',                                                            //
					null,                                                             //
					React.createElement(                                              //
						'a',                                                             //
						{ href: '#close', title: 'Close', className: 'close' },          //
						'X'                                                              //
					),                                                                //
					React.createElement('img', { src: '/images/text1.png', alt: 'first text', className: 'block-center max-width-100' })
				)                                                                  //
			),                                                                  //
			React.createElement(                                                //
				'div',                                                             //
				{ id: 'text2Modal', className: 'modalDialog' },                    //
				React.createElement(                                               //
					'div',                                                            //
					null,                                                             //
					React.createElement(                                              //
						'a',                                                             //
						{ href: '#close', title: 'Close', className: 'close' },          //
						'X'                                                              //
					),                                                                //
					React.createElement('img', { src: '/images/text2.png', alt: 'second text', className: 'block-center max-width-100' })
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
StoryPart2 = React.createClass({                                       // 128
	displayName: 'StoryPart2',                                            //
                                                                       //
	_handleBack: function () {                                            // 129
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart1, null), document.getElementById("content"));
	},                                                                    //
	_handleNext: function () {                                            // 133
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart3, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 137
		return React.createElement(                                          // 138
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 140
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							'Little did I know, just how much my life was going to change that day,'
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement('img', { src: '/images/alana-dog-maine.jpg', alt: 'Alana Maine Dog', className: 'block-center max-width-80', id: 'alanaDogMaineThumbnail' })
						),                                                               //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							'because I had no idea, that I was going to fall in love with the sweetest, most beautiful girl in the world...'
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleNext },
									'Next'                                                        //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
StoryPart3 = React.createClass({                                       // 166
	displayName: 'StoryPart3',                                            //
                                                                       //
	_handleBack: function () {                                            // 167
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart2, null), document.getElementById("content"));
	},                                                                    //
	_handleNext: function () {                                            // 171
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart4, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 175
		return React.createElement(                                          // 176
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 178
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							'We\'ve been all over the country together.'                    //
						),                                                               //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							React.createElement(                                            //
								'i',                                                           //
								null,                                                          //
								'From Ithaca'                                                  //
							)                                                               //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement('img', { src: '/images/ithaca-hiking.jpg', alt: 'Alana Alex Hiking', className: 'block-center max-width-80', id: 'alanaDogMaineThumbnail' })
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleNext },
									'Next'                                                        //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
StoryPart4 = React.createClass({                                       // 205
	displayName: 'StoryPart4',                                            //
                                                                       //
	_handleBack: function () {                                            // 206
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart3, null), document.getElementById("content"));
	},                                                                    //
	_handleNext: function () {                                            // 210
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart5, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 214
		return React.createElement(                                          // 215
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 217
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							React.createElement(                                            //
								'i',                                                           //
								null,                                                          //
								'To New York City'                                             //
							)                                                               //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement('img', { src: '/images/alana-met.jpg', alt: 'Alana New York Museum', className: 'block-center max-width-80', id: 'alanaDogMaineThumbnail' })
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleNext },
									'Next'                                                        //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
StoryPart5 = React.createClass({                                       // 242
	displayName: 'StoryPart5',                                            //
                                                                       //
	_handleBack: function () {                                            // 243
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart4, null), document.getElementById("content"));
	},                                                                    //
	_handleNext: function () {                                            // 247
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart6, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 251
		return React.createElement(                                          // 252
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 254
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							React.createElement(                                            //
								'i',                                                           //
								null,                                                          //
								'Up to Maine'                                                  //
							)                                                               //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement('img', { src: '/images/maine-bar.jpg', alt: 'Alana Alex Main bar', className: 'block-center max-width-80', id: 'alanaDogMaineThumbnail' })
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleNext },
									'Next'                                                        //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
StoryPart6 = React.createClass({                                       // 279
	displayName: 'StoryPart6',                                            //
                                                                       //
	_handleBack: function () {                                            // 280
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart5, null), document.getElementById("content"));
	},                                                                    //
	_handleNext: function () {                                            // 284
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart7, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 288
		return React.createElement(                                          // 289
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 291
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							React.createElement(                                            //
								'i',                                                           //
								null,                                                          //
								'Then back down to Pennsylvania'                               //
							)                                                               //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement('img', { src: '/images/alana-alex-philadelphia.jpg', alt: 'Alana Alex Philly', className: 'block-center max-width-80', id: 'alanaDogMaineThumbnail' })
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleNext },
									'Next'                                                        //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
StoryPart7 = React.createClass({                                       // 316
	displayName: 'StoryPart7',                                            //
                                                                       //
	_handleBack: function () {                                            // 317
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart6, null), document.getElementById("content"));
	},                                                                    //
	_handleNext: function () {                                            // 321
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart8, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 325
		return React.createElement(                                          // 326
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 328
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							React.createElement(                                            //
								'i',                                                           //
								null,                                                          //
								'And across to California...'                                  //
							)                                                               //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement('img', { src: '/images/alana-alex-sf.jpg', alt: 'Alana Alex SF', className: 'block-center max-width-80', id: 'alanaDogMaineThumbnail' })
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleNext },
									'Next'                                                        //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
StoryPart8 = React.createClass({                                       // 353
	displayName: 'StoryPart8',                                            //
                                                                       //
	_handleBack: function () {                                            // 354
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart7, null), document.getElementById("content"));
	},                                                                    //
	_handleNext: function () {                                            // 358
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart9, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 362
		return React.createElement(                                          // 363
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 365
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							'Every adventure with you is more spectacular than the last.'   //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement('img', { src: '/images/alana-alex-ice-cream.jpg', alt: 'Alana Alex ice cream', className: 'block-center max-width-80', id: 'alanaDogMaineThumbnail' })
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleNext },
									'Next'                                                        //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
StoryPart9 = React.createClass({                                       // 390
	displayName: 'StoryPart9',                                            //
                                                                       //
	_handleBack: function () {                                            // 391
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart8, null), document.getElementById("content"));
	},                                                                    //
	_handleNext: function () {                                            // 395
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart10, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 399
		return React.createElement(                                          // 400
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 402
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							'Life with you is amazing, Alana. I am my happiest when we are together.'
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement('img', { src: '/images/alana-alex-jordan-pond.jpg', alt: 'Alana Alex Jordan Pond', className: 'block-center max-width-80' })
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleNext },
									'Next'                                                        //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
StoryPart10 = React.createClass({                                      // 427
	displayName: 'StoryPart10',                                           //
                                                                       //
	_handleBack: function () {                                            // 428
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart9, null), document.getElementById("content"));
	},                                                                    //
	_handleNext: function () {                                            // 432
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(PhotoGrid, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 436
		return React.createElement(                                          // 437
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 439
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-6 col-sm-offset-3' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							'To many more adventures babe, wherever life may take us.'      //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'spacing' },                                       //
							React.createElement('img', { src: '/images/wine-tour.jpg', alt: 'Alana Alex Wine Tour', className: 'block-center max-width-80' })
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleNext },
									'Next'                                                        //
								)                                                              //
							)                                                               //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
PhotoGrid = React.createClass({                                        // 465
	displayName: 'PhotoGrid',                                             //
                                                                       //
	getInitialState: function () {                                        // 466
		return { photos: ["/images/grid/IMG_0006.jpg", "/images/grid/alana-alex-north-beach-bw.jpg", "/images/grid/IMG_0007.jpg", "/images/grid/IMG_0133.jpg", "/images/grid/first-formal.jpg", "/images/grid/alana-cup.jpg", "/images/grid/IMG_0151.jpg", "/images/grid/IMG_0198.jpg", "/images/grid/IMG_0201.jpg", "/images/grid/wine-tour2.jpg", "/images/grid/IMG_0217.jpg", "/images/grid/IMG_0263.jpg", "/images/grid/IMG_0269.jpg", "/images/grid/date-night2.jpg", "/images/grid/IMG_0278.jpg", "/images/grid/IMG_0643.jpg", "/images/grid/IMG_0289.jpg", "/images/grid/wine-tour1.jpg", "/images/grid/IMG_0545.jpg", "/images/grid/IMG_0546.jpg", "/images/grid/IMG_0550.jpg", "/images/grid/SF2.jpg", "/images/grid/IMG_0596.jpg", "/images/grid/IMG_0641.jpg", "/images/grid/IMG_0135.jpg", "/images/grid/IMG_0713.jpg", "/images/grid/alex-maine.jpg", "/images/grid/IMG_0718.jpg", "/images/grid/IMG_0721.jpg", "/images/grid/IMG_2461.jpg", "/images/grid/IMG_2478.jpg", "/images/grid/IMG_2587.jpg", "/images/grid/wine-tour3.jpg", "/images/grid/IMG_2601.jpg", "/images/grid/IMG_0069.jpg", "/images/grid/date-night.jpg", "/images/grid/graduation.jpg", "/images/grid/soccer-formal.jpg", "/images/grid/IMG_0642.jpg", "/images/grid/IMG_0637.jpg", "/images/grid/IMG_0633.jpg", "/images/grid/IMG_0409.jpg", "/images/grid/IMG_0288.jpg", "/images/grid/IMG_0273.jpg", "/images/grid/IMG_0139.jpg", "/images/grid/IMG_2607.jpg", "/images/grid/graduation2.jpg", "/images/grid/IMG_2612.jpg", "/images/grid/IMG_2618.jpg", "/images/grid/IMG_2629.jpg", "/images/grid/IMG_2638.jpg", "/images/grid/last-formal.jpg", "/images/grid/IMG_2644.jpg", "/images/grid/IMG_0117.jpg", "/images/grid/IMG_2647.jpg", "/images/grid/IMG_2772.jpg", "/images/grid/SF1.jpg", "/images/grid/first-formal-selfie.jpg", "/images/grid/IMG_0636.jpg", "/images/grid/maine-1.jpg", "/images/grid/second-formal.jpg", "/images/grid/wine-tour4.jpg", "/images/grid/IMG_0227.jpg"] };
	},                                                                    //
	componentDidMount: function () {                                      // 533
		// init Masonry                                                      //
		var $grid = $('.grid').masonry({                                     // 535
			// options...                                                       //
		});                                                                  //
		// layout Masonry after each image loads                             //
		$grid.imagesLoaded().progress(function () {                          // 539
			$grid.masonry({                                                     // 540
				columnWidth: 200,                                                  // 541
				isFitWidth: true                                                   // 542
			});                                                                 //
		});                                                                  //
	},                                                                    //
	_handleBack: function () {                                            // 546
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(StoryPart3, null), document.getElementById("content"));
	},                                                                    //
	_handleRestart: function () {                                         // 550
		ReactDOM.unmountComponentAtNode(document.getElementById("content"));
		ReactDOM.render(React.createElement(Login, null), document.getElementById("content"));
	},                                                                    //
	render: function () {                                                 // 554
                                                                       //
		var gridItems = this.state.photos.map((function (item, i) {          // 556
			return React.createElement(                                         // 557
				'div',                                                             //
				{ key: i, className: 'grid-item' },                                //
				React.createElement('img', { className: 'grid-item-pic', src: item })
			);                                                                  //
		}).bind(this));                                                      //
                                                                       //
		return React.createElement(                                          // 564
			'div',                                                              //
			{ className: 'row' },                                               //
			React.createElement(                                                //
				ReactCSSTransitionGroup,                                           // 566
				{ transitionName: 'transition', transitionAppear: true, transitionEnterTimeout: 500, transitionLeaveTimeout: 500, transitionAppearTimeout: 1500 },
				React.createElement(                                               //
					'div',                                                            //
					{ className: 'col-xs-12 col-sm-8 col-sm-offset-2' },              //
					React.createElement(                                              //
						'div',                                                           //
						{ className: 'transparent-background' },                         //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							'And here are some more of the many great moments that we have shared together.'
						),                                                               //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center' },                                   //
							'Happy Anniversary, for being in my life a whole year, Alana.  I look forward to many more in our future.'
						),                                                               //
						React.createElement(                                             //
							'h3',                                                           //
							{ className: 'text-center', id: 'cursive' },                    //
							'I love you.'                                                   //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'row' },                                           //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-right', onClick: this._handleBack },
									'Back'                                                        //
								)                                                              //
							),                                                              //
							React.createElement(                                            //
								'div',                                                         //
								{ className: 'col-xs-6' },                                     //
								React.createElement(                                           //
									'button',                                                     //
									{ className: 'btn purple float-left', onClick: this._handleRestart },
									'Restart'                                                     //
								)                                                              //
							)                                                               //
						),                                                               //
						React.createElement(                                             //
							'div',                                                          //
							{ className: 'grid' },                                          //
							gridItems                                                       //
						)                                                                //
					)                                                                 //
				)                                                                  //
			)                                                                   //
		);                                                                   //
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=app.jsx.map
