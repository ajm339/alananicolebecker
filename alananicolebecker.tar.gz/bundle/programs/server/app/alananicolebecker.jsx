(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// alananicolebecker.jsx                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
  Meteor.startup(function () {                                         // 2
    // code to run on server at startup                                //
    ReactDOM.render(React.createElement(App, null), document.getElementById("render-target"));
  });                                                                  //
}                                                                      //
                                                                       //
// if (Meteor.isServer) {                                              //
//   Meteor.startup(function () {                                      //
//     // code to run on server at startup                             //
//   });                                                               //
// }                                                                   //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=alananicolebecker.jsx.map
